<html>

<head>
<meta http-equiv="Content-Language" content="fr">
<meta http-equiv="Description" content="Association of Philatelic Web Publishers">
<meta http-equiv="Keywords" content="stamps, Web Publishers, association,  philaty, philatelic, collectors, collecting, timbres, Briefmarken">
<meta name="GENERATOR" content="Microsoft FrontPage 4.0">
<meta name="ProgId" content="FrontPage.Editor.Document">
<title></title>
<base target="Member's-Page">
</head>

<body bgproperties="fixed" link="#FFFFFF" vlink="#FF0000" alink="#FFFF00" topmargin="12" bgcolor="#FFF5D7">
<!-- PureASP.asp revised 07-01-98  -->

<p align="center"><img border="0" src="../ttl-pwo.gif"></p>

<p align="center"><b><font face="Arial" color="#000080" size="4">NOS MEMBRES</font></b></p>
<div align="center">
  <center>
  <table width="100%" border="1" background="../../WorldMap.gif" bordercolorlight="#FFFFFF">
    <thead>
      <tr>
        <td align="center" ><b><font color="#FF0000">Membre</font></b></td>
        <td align="center" ><b><font color="#FF0000">Pays</font></b></td>
        <td align="center" ><b><font color="#FF0000">Langue(s)</font></b></td>
        <td align="center" ><b><font color="#FF0000">Nom du site</font></b></td>
        <td align="center" ><b><font color="#FF0000">Link</font></b></td>
        <td align="center" ><font color="#FF0000"><b>Type</b></font></td>
      </tr>
    </thead>
    <tbody>
      <!--webbot bot="DatabaseRegionStart" startspan
      s-columnnames="Name,Type,URL,Author,Country,Lang,E-mail"
      s-columntypes="200,200,201,200,200,200,200" s-dataconnection="apwp"
      b-tableformat="TRUE" b-menuformat="FALSE" s-menuchoice="Name" s-menuvalue="Name"
      b-tableborder="TRUE" b-tableexpand="TRUE" b-tableheader="TRUE"
      b-listlabels="TRUE" b-listseparator="TRUE" i-ListFormat="0"
      b-makeform="TRUE" s-recordsource
      s-displaycolumns="Name,Type,URL,Author,Country,Lang,E-mail" s-criteria
      s-order s-sql="SELECT * FROM Members ORDER BY Author ASC"
      b-procedure="FALSE" clientside SuggestedExt="asp" s-DefaultFields
      s-NoRecordsFound="No records found that match your search criteria"
      i-MaxRecords="0" i-GroupSize="0" BOTID="0"
      u-dblib="../../_fpclass/fpdblib.inc"
      u-dbrgn1="../../_fpclass/fpdbrgn1.inc"
      u-dbrgn2="../../_fpclass/fpdbrgn2.inc" tag="TBODY"
      local_preview="&lt;tr&gt;&lt;td colspan=64 bgcolor=&quot;#FFFF00&quot; align=&quot;left&quot; width=&quot;100%&quot;&gt;&lt;font color=&quot;#000000&quot;&gt;Database Results regions will not preview unless this page is fetched from a Web server with a web browser. The following table row will repeat once for every record returned by the query.&lt;/font&gt;&lt;/td&gt;&lt;/tr&gt;"
      preview="&lt;tr&gt;&lt;td colspan=64 bgcolor=&quot;#FFFF00&quot; align=&quot;left&quot; width=&quot;100%&quot;&gt;&lt;font color=&quot;#000000&quot;&gt;This is the start of a Database Results region. The page must be fetched from a web server with a web browser to display correctly; the current web is stored on your local disk or network.&lt;/font&gt;&lt;/td&gt;&lt;/tr&gt;" b-WasTableFormat="TRUE" --><!--#include file="../../_fpclass/fpdblib.inc"-->
<%
fp_sQry="SELECT * FROM Members ORDER BY Author ASC"
fp_sDefault=""
fp_sNoRecords="<tr><td colspan=7 align=left width=""100%"">No records found that match your search criteria</td></tr>"
fp_sDataConn="apwp"
fp_iMaxRecords=0
fp_iCommandType=1
fp_iPageSize=0
fp_fTableFormat=True
fp_fMenuFormat=False
fp_sMenuChoice="Name"
fp_sMenuValue="Name"
fp_iDisplayCols=7
fp_fCustomQuery=True
BOTID=0
fp_iRegion=BOTID
%>
<!--#include file="../../_fpclass/fpdbrgn1.inc"-->
<!--webbot bot="DatabaseRegionStart" i-CheckSum="34872" endspan -->
      <tr>
        <td align="center"><font color="#FFFFFF" face="Arial" size="2"><a href="mailto:<%=FP_FieldLink(fp_rs,"E-mail")%>"><!--webbot bot="DatabaseResultColumn" startspan
          s-columnnames="Name,Type,URL,Author,Country,Lang,E-mail"
          s-column="Author" b-tableformat="TRUE" b-hasHTML="TRUE" clientside
          local_preview="&lt;font size=&quot;-1&quot;&gt;&amp;lt;&amp;lt;&lt;/font&gt;Author&lt;font size=&quot;-1&quot;&gt;&amp;gt;&amp;gt;&lt;/font&gt;"
          preview="&lt;font size=&quot;-1&quot;&gt;&amp;lt;&amp;lt;&lt;/font&gt;Author&lt;font size=&quot;-1&quot;&gt;&amp;gt;&amp;gt;&lt;/font&gt;" --><%=FP_Field(fp_rs,"Author")%><!--webbot
          bot="DatabaseResultColumn" i-CheckSum="13508" endspan -->
          </a>
          </font>
        </td>
        <td align="center"><font color="#FFFFFF" face="Arial" size="2"><!--webbot bot="DatabaseResultColumn" startspan
          s-columnnames="Name,Type,URL,Author,Country,Lang,E-mail"
          s-column="Country" b-tableformat="TRUE" b-hasHTML="FALSE" clientside
          local_preview="&lt;font size=&quot;-1&quot;&gt;&amp;lt;&amp;lt;&lt;/font&gt;Country&lt;font size=&quot;-1&quot;&gt;&amp;gt;&amp;gt;&lt;/font&gt;"
          preview="&lt;font size=&quot;-1&quot;&gt;&amp;lt;&amp;lt;&lt;/font&gt;Country&lt;font size=&quot;-1&quot;&gt;&amp;gt;&amp;gt;&lt;/font&gt;" --><%=FP_FieldVal(fp_rs,"Country")%><!--webbot
          bot="DatabaseResultColumn" i-CheckSum="13796" endspan -->
          </font>
        </td>
        <td align="center"><font color="#FFFFFF" face="Arial" size="2"><!--webbot bot="DatabaseResultColumn" startspan
          s-columnnames="Name,Type,URL,Author,Country,Lang,E-mail"
          s-column="Lang" b-tableformat="TRUE" b-hasHTML="FALSE" clientside
          local_preview="&lt;font size=&quot;-1&quot;&gt;&amp;lt;&amp;lt;&lt;/font&gt;Lang&lt;font size=&quot;-1&quot;&gt;&amp;gt;&amp;gt;&lt;/font&gt;"
          preview="&lt;font size=&quot;-1&quot;&gt;&amp;lt;&amp;lt;&lt;/font&gt;Lang&lt;font size=&quot;-1&quot;&gt;&amp;gt;&amp;gt;&lt;/font&gt;" --><%=FP_FieldVal(fp_rs,"Lang")%><!--webbot
          bot="DatabaseResultColumn" i-CheckSum="3777" endspan -->
          </font>
        </td>
        <td align="center"><font color="#FFFFFF" face="Arial" size="2"><!--webbot bot="DatabaseResultColumn" startspan
          s-columnnames="Name,Type,URL,Author,Country,Lang,E-mail"
          s-column="Name" b-tableformat="TRUE" b-hasHTML="FALSE" clientside
          local_preview="&lt;font size=&quot;-1&quot;&gt;&amp;lt;&amp;lt;&lt;/font&gt;Name&lt;font size=&quot;-1&quot;&gt;&amp;gt;&amp;gt;&lt;/font&gt;"
          preview="&lt;font size=&quot;-1&quot;&gt;&amp;lt;&amp;lt;&lt;/font&gt;Name&lt;font size=&quot;-1&quot;&gt;&amp;gt;&amp;gt;&lt;/font&gt;" --><%=FP_FieldVal(fp_rs,"Name")%><!--webbot
          bot="DatabaseResultColumn" i-CheckSum="3900" endspan -->
          </font>
        </td>
        <td align="center"><font color="#FFFFFF" face="Arial"><a href="<%=FP_FieldLink(fp_rs,"URL")%>"><i>URL</i></a></font>
        </td>
        <td align="center"><font color="#FFFFFF" face="Arial" size="2"><!--webbot bot="DatabaseResultColumn" startspan
          s-columnnames="Name,Type,URL,Author,Country,Lang,E-mail"
          s-column="Type" b-tableformat="TRUE" b-hasHTML="FALSE" clientside
          local_preview="&lt;font size=&quot;-1&quot;&gt;&amp;lt;&amp;lt;&lt;/font&gt;Type&lt;font size=&quot;-1&quot;&gt;&amp;gt;&amp;gt;&lt;/font&gt;"
          preview="&lt;font size=&quot;-1&quot;&gt;&amp;lt;&amp;lt;&lt;/font&gt;Type&lt;font size=&quot;-1&quot;&gt;&amp;gt;&amp;gt;&lt;/font&gt;" --><%=FP_FieldVal(fp_rs,"Type")%><!--webbot
          bot="DatabaseResultColumn" i-CheckSum="7359" endspan -->
          </font>
        </td>
      </tr>
      <!--webbot bot="DatabaseRegionEnd" startspan b-tableformat="TRUE"
      b-menuformat="FALSE" u-dbrgn2="../../_fpclass/fpdbrgn2.inc"
      i-groupsize="0" clientside tag="TBODY"
      local_preview="&lt;tr&gt;&lt;td colspan=64 bgcolor=&quot;#FFFF00&quot; align=&quot;left&quot; width=&quot;100%&quot;&gt;&lt;font color=&quot;#000000&quot;&gt;This is the end of a Database Results region.&lt;/font&gt;&lt;/td&gt;&lt;/tr&gt;"
      preview="&lt;tr&gt;&lt;td colspan=64 bgcolor=&quot;#FFFF00&quot; align=&quot;left&quot; width=&quot;100%&quot;&gt;&lt;font color=&quot;#000000&quot;&gt;This is the end of a Database Results region.&lt;/font&gt;&lt;/td&gt;&lt;/tr&gt;" --><!--#include file="../../_fpclass/fpdbrgn2.inc"-->
<!--webbot bot="DatabaseRegionEnd" i-CheckSum="65064" endspan -->
    </tbody>
  </table>
  </center>
</div>

<table border="1" bordercolorlight="#800000" cellspacing="1" cellpadding="0" background="../../WorldMap.gif" width="100%">
  <tr>
    <td align="center" bgcolor="#FFFF00" height="28" background="../../WorldMap.gif">&nbsp;</td>
    <td align="center" bgcolor="#FFFF00" height="28" background="../../WorldMap.gif">&nbsp;</td>
    <td align="center" bgcolor="#FFFF00" height="28" background="../../WorldMap.gif">&nbsp;</td>
    <td align="center" bgcolor="#FFFF00" height="28" background="../../WorldMap.gif">&nbsp;</td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFF00" height="28" background="../../WorldMap.gif"><p align="center"><font color="#00FF00"><em><strong>CES
      CADRES </strong></em></font></td>
    <td align="center" bgcolor="#FFFF00" height="28" background="../../WorldMap.gif"><p align="center"><font color="#00FF00"><em><strong>VOUS</strong></em></font></td>
    <td align="center" bgcolor="#FFFF00" height="28" background="../../WorldMap.gif"><p align="center"><font color="#00FF00"><em><strong>SONT</strong></em></font></td>
    <td align="center" bgcolor="#FFFF00" height="28" background="../../WorldMap.gif"><font color="#00FF00"><em><strong>R�SERV�S
      !!!&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </strong></em></font></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFF00" nowrap height="30" background="../../WorldMap.gif"><img src="../../anim_subscribe.gif" width="136" height="30"></td>
    <td align="center" bgcolor="#FFFF00" nowrap height="30" background="../../WorldMap.gif">&nbsp;</td>
    <td align="center" bgcolor="#FFFF00" nowrap height="30" background="../../WorldMap.gif"><font color="#00FF00"><strong>Entr�e libre!</strong></font></td>
    <td align="center" bgcolor="#FFFF00" nowrap height="30" background="../../WorldMap.gif">&nbsp;<a href="apwp-db-update.asp" target="_blank"><font color="#FF0000" face="Arial"><strong><em>Hier klicken zum Beitreten</em></strong></font></a></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFF00" nowrap height="30" valign="middle" background="../../WorldMap.gif"><a href="apwp-db-update-fr.asp" target="_blank"><font face="Arial"><strong><em>Cliquer
    ici pour s'inscrire</em></strong></font></a></td>
    <td align="center" bgcolor="#FFFF00" nowrap height="30" background="../../WorldMap.gif"><img src="../../anim_subscribe.gif" width="136" height="30"></td>
    <td align="center" bgcolor="#FFFF00" nowrap height="30" background="../../WorldMap.gif"><font color="#00FF00">&nbsp;<strong>Free Entry!</strong></font></td>
    <td align="center" bgcolor="#FFFF00" nowrap height="30" background="../../WorldMap.gif"><a href="apwp-db-update-fr.asp" target="_blank"><font face="Arial"><strong><em>Cliquer
    ici pour s'inscrire</em></strong></font></a></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFF00" nowrap height="30" background="../../WorldMap.gif"><font color="#00FF00" face="Arial"><strong>Keine Angebote!</strong></font></td>
    <td align="center" bgcolor="#FFFF00" nowrap height="30" background="../../WorldMap.gif">&nbsp;</td>
    <td align="center" bgcolor="#FFFF00" nowrap height="30" background="../../WorldMap.gif"><img src="../../anim_subscribe.gif" width="136" height="30"></td>
    <td align="center" bgcolor="#FFFF00" nowrap height="30" background="../../WorldMap.gif"><b><font FACE="Arial" SIZE="2" color="#00FF00">AUCUNE
      offre commerciale</font></b></td>
  </tr>
  <tr>
    <td align="center" bgcolor="#FFFF00" nowrap height="30" background="../../WorldMap.gif"><font color="#00FF00" face="Arial"><strong>Eintritt ist kostenlos!</strong></font></td>
    <td align="center" bgcolor="#FFFF00" nowrap height="30" background="../../WorldMap.gif">&nbsp;<font size="2">&nbsp;<strong><font color="#FF0000" face="Arial">Click
      <a href="apwp-db-update.asp"><i>
    here</i></a> to join us</font></strong></font></td>
    <td align="center" bgcolor="#FFFF00" nowrap height="30" background="../../WorldMap.gif">&nbsp;<strong><font color="#FF0000"> </font><font color="#00FF00">NO Hidden Costs!</font></strong></td>
    <td align="center" bgcolor="#FFFF00" nowrap height="30" background="../../WorldMap.gif"><img src="../../anim_subscribe.gif" width="136" height="30"></td>
  </tr>
</table>

<p><b><font FACE="Arial" COLOR="#000080">Information l�gale : ceci est une
liste priv�e, propri�t� de la </font><font FACE="Arial" COLOR="#ff0000">Philatelic
Webmasters Organization</font><font FACE="Arial" COLOR="#000080">. Elle a fait
l'objet d'un d�p�t l�gal. Il est strictement interdit de la copier ou de la
distribuer, ainsi que de l'utiliser pour faire parvenir des offres commerciales
� des membres de la PWO.</font></b></p>

<table border="0" cellspacing="0" width="100%" cellpadding="0">
  <tr>
    <td valign="middle"><b><font FACE="Arial" SIZE="1">Cr�� en f�vrier 2001.
      Modifi� le </font></b><strong><font face="Arial" size="1">
    <!--webbot bot="TimeStamp" s-format="%m/%d/%y" s-type="EDITED" startspan -->09/16/01<!--webbot bot="TimeStamp" endspan i-checksum="12454" --></font></strong><b><font FACE="Arial" SIZE="1">.<br>
      Copyright � 2001 PWO et Victor Manta, Suisse.<br>
      La diffusion de cette liste est strictement interdite.<br>
      Tous droits r�serv�s dans le monde entier.</font></b></td>
    <td rowspan="2"><p align="center"><a href="http://www.pwmo.org"><img border="0" src="../images/pwo-logo.gif"></a></td>
  </tr>
  <tr>
    <td valign="middle"><b><font FACE="Arial" SIZE="1" COLOR="#ff0000">Apr�s
      avoir adh�r�, les membres sont autoris�s (et fortement encourag�s) �
      utiliser<br>
      notre logo (ici � droite) en y adjoignant un lien vers le site PWO :</font></b><strong><font face="Arial" color="#FF0000" size="1">
      http://pwmo.org</font></strong></td>
  </tr>
</table>

</body>
</html>
